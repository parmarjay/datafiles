# -*- coding: utf-8 -*-
"""
Created on Tue Feb 25 14:25:53 2020

@author: jay.p
"""

from ibapi.client import EClient
from ibapi.wrapper import EWrapper
from ibapi.contract import Contract
import time

# http://interactivebrokers.github.io/tws-api/basic_contracts.html#gsc.tab=0
# https://interactivebrokers.github.io/tws-api/basic_contracts.html

class TestApp(EClient, EWrapper):
    def __init__(self):
        EWrapper.__init__(self)
        EClient.__init__(self, self)
        
    def error(self, reqId, errorCode, errorString):
        print("Error: ", reqId, " ", errorCode, " ", errorString)
        
    def contractDetails(self, reqId, contractDetails):
        print('Contract Details Start: ', reqId, contractDetails)
        
    def contractDetailsEnd(self, reqId):
        print('Contract Details End: ', reqId)
        time.sleep(2)
        self.stop()
    
    def stop(self):
        self.done = True
        self.disconnect()
        

def main():
    app = TestApp()  
    app.connect(host='127.0.0.1', port=7496, clientId=0)    
    print('App Connected to TWS')
    
    time.sleep(3)
    
    contract = Contract()
    
    # Stocks
    contract.symbol = 'AAPL'
    contract.currency = 'USD'
    contract.secType = 'STK'
    contract.exchange = 'SMART'
    #contract.primaryExchange = 'NASDAQ'
    
    # FX Pairs
#    contract.symbol = 'EUR'
#    contract.currency = 'USD'
#    contract.secType = 'CASH'
#    contract.exchange = 'IDEALPRO'
    
    # Futures
#    contract.symbol = 'AAPL'
#    contract.secType = 'FUT'
#    contract.exchange = 'ONE'
#    contract.currency = 'USD'
#    contract.lastTradeDateOrContractMonth = '202002'
    
    # Options
#    contract.symbol = 'AAPL'
#    contract.secType = 'OPT'
#    contract.exchange = 'SMART'
#    contract.currency = 'USD'
#    contract.lastTradeDateOrContractMonth = '202002'
#    contract.strike = 300
#    contract.right = 'C'
#    contract.multiplier = '100'
    
    app.reqContractDetails(10, contract)
    
    app.run()
    
if __name__ == '__main__':
    main()