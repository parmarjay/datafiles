# -*- coding: utf-8 -*-
"""
Created on Tue Feb 25 16:31:05 2020

@author: jay.p
"""

# To be Done
# Implement Order Cancellation
# Implement Order Modification

from ibapi.client import EClient
from ibapi.wrapper import EWrapper

from ibapi.contract import Contract

from ibapi.order import Order
from ibapi.order_condition import OrderCondition
from ibapi.order_state import OrderState

from ibapi.execution import Execution
from ibapi.execution import ExecutionFilter

from threading import Timer


class TestApp(EClient, EWrapper):
    def __init__(self):
        EWrapper.__init__(self)
        EClient.__init__(self, self)
        
    def error(self, reqId, errorCode, errorString):
        print("Error: ", reqId, " ", errorCode, " ", errorString)
        
    def nextValidId(self, orderId):
        self.nextValidId = orderId
        self.start()
        
    def start(self):
        contract = Contract()
        contract.symbol = 'EUR'
        contract.secType = 'CASH'
        contract.currency = 'USD'
        contract.exchange = 'IDEALPRO'
        
        order = Order()
        order.action = 'SELL'
        order.totalQuantity = 20000
        order.orderType = 'MKT' # https://interactivebrokers.github.io/tws-api/basic_orders.html
        
        #order.orderType = 'LMT'
        #order.lmtPrice = 0
        
        self.placeOrder(self.nextValidId, contract, order)
        
    def stop(self):
        self.done = True
        self.disconnect()
    
    def openOrder(self, orderId, contract, order, orderState):
        print('\nOpenOrder:-',
              '\nOrderId: ', orderId,
              '\nSymbol: ', contract.symbol,
              '\nSecType: ', contract.secType,
              '\nExchange: ', contract.exchange,
              '\nAction: ', order.action,
              '\nStatus: ', orderState.status)
    
    def orderStatus(self, orderId, status, filled, remaining, 
                    avgFillPrice, permId, parentId, lastFillPrice, clientId,
                    whyHeld, mktCapPrice):
        print('\nOrder Status:-',
              '\nOrderId: ', orderId,
              '\nStatus: ', status,
              '\nFilled:', filled,
              '\nRemaining: ', remaining,
              '\nAvgFillPrice:', avgFillPrice,
              '\nPermId: ', permId,
              '\nParentId: ', parentId,
              '\nLastFillPrice:', lastFillPrice,
              '\nClientId: ', clientId,
              '\nWhyHeld: ', whyHeld,
              '\nMktCapPrice: ', mktCapPrice)
        
    def execDetails(self, reqId, contract, execution):
        print('\nExecDetails:-',
              '\nId: ', reqId,
              '\nSymbol: ', contract.symbol,
              '\nExecutionId:', execution.execId,
              '\nOrderId: ', execution.orderId,
              '\nQty:', execution.shares,
              '\nLastLiquidity: ', execution.lastLiquidity)
        
    def openOrderEnd(self):
        print('OpenOrderEnd')
        
    
def main():
    app = TestApp()
    
    app.connect('127.0.0.1', 7496, 0)
    
    Timer(30, app.stop).start()
    app.run()
    

if __name__ == '__main__':
    main()