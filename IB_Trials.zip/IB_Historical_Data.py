# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 11:59:47 2020

@author: jay.p
"""

from ibapi.contract import Contract
from ibapi.client import EClient
from ibapi.wrapper import EWrapper
from threading import Timer
from datetime import datetime

class TestApp(EClient, EWrapper):
    def __init__(self):
        EClient.__init__(self, self)
    
    def nextValidId(self, orderId):
        self.nextValidId = orderId
        print(self.nextValidId)
        self.start()
        
    def error(self, reqId, errorCode, errorString):
        if reqId == -1:
            pass
        else:
            print("Error: ", reqId, " ", errorCode, " ", errorString)
        #print("Error: ", reqId, " ", errorCode, " ", errorString)
        
    def start(self):
        contract = Contract()
        contract.symbol = 'USD'
        contract.currency = 'JPY'
        contract.exchange = 'IDEALPRO'
        contract.secType = 'CASH'
        
        query_time = datetime.today().strftime('%Y%m%d %H:%M:%S')
        self.reqHistoricalData(self.nextValidId, contract, query_time, '5 D', '1 day', 'MIDPOINT', 0, 1, False, [])
        
    def historicalData(self, reqId, bar):
        print('Historical Data', reqId, 'Date: ', bar.date, 'Close: ', bar.close, 'Count: ', bar.barCount)
        # bar.open, bar.high, bar.low, bar.volume, bar.average
        
    def historicalDataEnd(self, reqId, start, end):
        print('\nHistorical Data End', reqId, 'from ', start, 'to ', end)
    
    def stop(self):
        self.done = True
        self.disconnect()

def main():
    app = TestApp()
    app.connect(host='127.0.0.1', port=7496, clientId=0)
    Timer(2, app.stop).start()
    app.run()
    
if __name__ == '__main__':
    main()