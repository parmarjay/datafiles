# -*- coding: utf-8 -*-
"""
Created on Thu Feb 27 17:11:28 2020

@author: jay.p
"""

from ibapi.client import EClient
from ibapi.wrapper import EWrapper
from threading import Timer
from ibapi.contract import Contract

class TestApp(EClient, EWrapper):
    def __init__(self):
        EClient.__init__(self, self)
        
    def nextValidId(self, orderId):
        self.nextValidId = orderId
        self.start()
        
    def start(self):
        contract = Contract()
        contract.symbol = 'EUR'
        contract.currency = 'USD'
        contract.exchange = 'IDEALPRO'
        contract.secType = 'CASH'
        
        self.reqContractDetails(self.nextValidId, contract)
        
    def contractDetails(self, reqId, contractDetails):
        print('ContractDetails: ', reqId, contractDetails)
        
    def contractDetailsEnd(self, reqId):
        print('ContractDetailsEnd: ', reqId)
    
    def stop(self):
        self.done = True
        self.disconnect()
        
def main():
    app = TestApp()
    app.connect(host='127.0.0.1', port=7496, clientId=1)
    Timer(20, app.stop).start()
    app.run()
    
if __name__ == '__main__':
    main()